import Image from "next/image";

export function DeviceShowcase() {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-6 text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          <span className="text-blue-500">#KeepEvolving</span>
        </h2>
      </div>

      <div className="relative max-w-4xl mx-auto">
        <div className="flex justify-center">
          {/* Phone mockups with screenshots */}
          <div className="relative w-[280px] h-[560px] inline-block">
            <div className="absolute inset-0 bg-black rounded-[40px] border-[8px] border-gray-800 shadow-xl"></div>
            <div className="absolute inset-y-0 inset-x-0 m-[8px] bg-gray-900 rounded-[32px] overflow-hidden">
              {/* Main settings screenshot */}
              <Image
                src="https://ext.same-assets.com/3249466806/1745345089.webp"
                alt="Evolution X Settings"
                fill
                className="object-cover"
              />
            </div>
            {/* Phone camera and speaker */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-24 h-6 bg-black rounded-full"></div>
          </div>

          {/* Additional phone mockups can be added here with slight positioning adjustments */}
          <div className="relative w-[280px] h-[560px] inline-block -ml-20 mt-12 hidden md:block">
            <div className="absolute inset-0 bg-black rounded-[40px] border-[8px] border-gray-800 shadow-xl"></div>
            <div className="absolute inset-y-0 inset-x-0 m-[8px] bg-gray-900 rounded-[32px] overflow-hidden">
              {/* Evolver menu screenshot */}
              <Image
                src="https://ext.same-assets.com/3249466806/2425398476.webp"
                alt="Evolution X Customization"
                fill
                className="object-cover"
              />
            </div>
            {/* Phone camera and speaker */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-24 h-6 bg-black rounded-full"></div>
          </div>

          <div className="relative w-[280px] h-[560px] inline-block -ml-32 mt-24 hidden lg:block">
            <div className="absolute inset-0 bg-black rounded-[40px] border-[8px] border-gray-800 shadow-xl"></div>
            <div className="absolute inset-y-0 inset-x-0 m-[8px] bg-gray-900 rounded-[32px] overflow-hidden">
              {/* Lockscreen screenshot */}
              <Image
                src="https://ext.same-assets.com/3249466806/3115607893.webp"
                alt="Evolution X Lockscreen"
                fill
                className="object-cover"
              />
            </div>
            {/* Phone camera and speaker */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-24 h-6 bg-black rounded-full"></div>
          </div>
        </div>

        {/* Indicator dots */}
        <div className="flex justify-center space-x-2 mt-8">
          {[...Array(9)].map((_, i) => (
            <div
              key={i}
              className={`w-2.5 h-2.5 rounded-full ${i === 4 ? 'bg-blue-500' : 'bg-gray-700'}`}
            ></div>
          ))}
        </div>
      </div>
    </section>
  );
}
