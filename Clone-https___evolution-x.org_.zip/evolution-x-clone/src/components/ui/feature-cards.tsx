import Image from "next/image";
import Link from "next/link";

export function FeatureCards() {
  return (
    <section className="py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Android 15 Card */}
          <div className="bg-gradient-to-br from-black to-evolution-dark p-8 rounded-2xl flex flex-col md:flex-row items-center md:items-start gap-6 overflow-hidden relative">
            <div className="z-10 flex-1">
              <h3 className="text-2xl font-bold mb-4">Get Android 15 for your device now</h3>
              <p className="text-gray-300 mb-6">
                Experience the latest Android version with all the Evolution X customizations.
              </p>
              <Link
                href="/downloads"
                className="inline-block px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-full transition-colors duration-300"
              >
                Download
              </Link>
            </div>
            <div className="flex-shrink-0 z-10">
              <Image
                src="/images/androidversion.webp"
                alt="Android 15"
                width={120}
                height={120}
                className="h-auto w-28 md:w-32"
              />
            </div>
            <div className="absolute top-0 right-0 w-full h-full bg-[url('/images/wave-pattern.svg')] opacity-10" />
          </div>

          {/* Frequent Updates Card */}
          <div className="bg-gradient-to-br from-black to-evolution-dark p-8 rounded-2xl">
            <h3 className="text-2xl font-bold mb-4">Frequent Updates & Latest Security Patches</h3>
            <p className="text-gray-300">
              We provide frequent updates amongst most custom ROMs. These updates aim to be in a stable state and are guaranteed to be on the latest security patches.
            </p>
          </div>

          {/* Pixel Look & Feel Card */}
          <div className="bg-gradient-to-br from-black to-evolution-dark p-8 rounded-2xl">
            <h3 className="text-2xl font-bold mb-4">Pixel Look & Feel</h3>
            <p className="text-gray-300">
              Evolution X provides you with the perfect Pixel experience, imitating Google Pixel devices, with additional customizations.
            </p>
          </div>

          {/* About Card */}
          <div className="bg-gradient-to-br from-black to-evolution-dark p-8 rounded-2xl relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <span className="text-xs text-blue-400">#KeepEvolving</span>
            </div>
            <h3 className="text-2xl font-bold mb-4">About Evolution X</h3>
            <p className="text-gray-300">
              Evolution X aims to provide users with a Pixel-like feel at first glance, with additional features at their disposal.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
