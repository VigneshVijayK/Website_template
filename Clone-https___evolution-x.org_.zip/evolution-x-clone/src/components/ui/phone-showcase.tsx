import Image from "next/image";

export function PhoneShowcase() {
  return (
    <section className="py-20 overflow-hidden">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-16">
          <span className="gradient-text">#KeepEvolving</span>
        </h2>

        <div className="relative h-[500px] md:h-[600px] mx-auto">
          {/* We'll create a mockup with phone screenshots */}
          <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 shadow-2xl rounded-3xl overflow-hidden border-8 border-gray-900 w-[240px] md:w-[270px]">
            <div className="relative w-full h-[500px] md:h-[540px] bg-gray-900">
              <div className="absolute inset-0 flex items-center justify-center text-gray-500 text-sm">
                Evolver Settings Screen
              </div>
            </div>
          </div>

          {/* Left phone */}
          <div className="absolute left-[10%] md:left-[20%] top-1/2 transform -translate-y-1/2 z-10 rotate-[-12deg] shadow-2xl rounded-3xl overflow-hidden border-8 border-gray-900 w-[200px] md:w-[240px] opacity-70">
            <div className="relative w-full h-[420px] md:h-[490px] bg-gray-900">
              <div className="absolute inset-0 flex items-center justify-center text-gray-500 text-sm">
                Settings Screen
              </div>
            </div>
          </div>

          {/* Right phone */}
          <div className="absolute right-[10%] md:right-[20%] top-1/2 transform -translate-y-1/2 z-10 rotate-[12deg] shadow-2xl rounded-3xl overflow-hidden border-8 border-gray-900 w-[200px] md:w-[240px] opacity-70">
            <div className="relative w-full h-[420px] md:h-[490px] bg-gray-900">
              <div className="absolute inset-0 flex items-center justify-center text-gray-500 text-sm">
                Lockscreen
              </div>
            </div>
          </div>

          {/* Bottom navigation dots */}
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full ${i === 4 ? 'bg-evolution-blue' : 'bg-gray-600'}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
