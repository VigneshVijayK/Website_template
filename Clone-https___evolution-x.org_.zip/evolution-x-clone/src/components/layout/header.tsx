"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Home", target: "_self" },
  { href: "/team", label: "Team", target: "_self" },
  { href: "/downloads", label: "Download", target: "_self" },
  { href: "/blog", label: "Blog", target: "_self" },
  { href: "/merch", label: "Merch", target: "_self" },
  { href: "https://crowdin.com/project/evolution_x", label: "Translations", target: "_blank", icon: "/icons/xlogo.svg" },
  { href: "https://wiki.evolution-x.org/", label: "Wiki", target: "_blank", icon: "/icons/xlogo.svg" },
];

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="py-4 px-6 sticky top-0 z-50 backdrop-blur-lg bg-opacity-75 bg-evolution-dark/50">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <Image
            src="/icons/evoXLogo.svg"
            alt="Evolution X Logo"
            width={40}
            height={40}
            className="h-10 w-auto"
          />
        </Link>

        {/* Desktop Menu */}
        <nav className="hidden md:flex space-x-8 items-center">
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              target={item.target}
              className={cn(
                "text-base font-medium relative group",
                item.href === "/" ? "text-evolution-blue" : "text-white hover:text-evolution-blue/80 transition-colors"
              )}
            >
              {item.label}
              {item.href === "/" && (
                <span className="absolute -bottom-1 left-0 w-full h-[2px] bg-evolution-blue" />
              )}
              {item.href !== "/" && (
                <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-evolution-blue group-hover:w-full transition-all duration-300" />
              )}
              {item.icon && (
                <Image
                  src={item.icon}
                  alt=""
                  width={12}
                  height={12}
                  className="inline-block ml-1 w-3 h-3"
                />
              )}
            </Link>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden flex items-center p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <Image
            src="/icons/menu.svg"
            alt="Menu"
            width={24}
            height={24}
            className="text-white"
          />
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      <div
        className={cn(
          "fixed inset-0 top-[72px] bg-black bg-opacity-90 md:hidden transition-opacity duration-300 z-40",
          isMobileMenuOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
      >
        <div className="flex flex-col px-8 py-6 space-y-4">
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              target={item.target}
              className={cn(
                "text-xl py-2 font-medium",
                item.href === "/" ? "text-evolution-blue" : "text-white"
              )}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {item.label}
              {item.icon && (
                <Image
                  src={item.icon}
                  alt=""
                  width={12}
                  height={12}
                  className="inline-block ml-1 w-3 h-3"
                />
              )}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
}
