import Link from "next/link";
import Image from "next/image";

export function Footer() {
  return (
    <footer className="mt-auto py-6 border-t border-gray-800">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex flex-col items-center md:items-start mb-6 md:mb-0">
            <Link href="/">
              <Image
                src="/icons/evolution.svg"
                alt="Evolution X"
                width={180}
                height={40}
                className="h-10 w-auto"
              />
            </Link>
            <p className="text-blue-500 mt-1 text-sm">#KeepEvolving</p>
          </div>

          <div className="flex space-x-4">
            <Link
              href="https://discord.com/invite/evolution-x-670512508871639041"
              target="_blank"
              className="hover:opacity-80 transition-opacity"
            >
              <Image src="/icons/discordicon.svg" alt="Discord" width={28} height={28} />
            </Link>
            <Link
              href="https://github.com/Evolution-X"
              target="_blank"
              className="hover:opacity-80 transition-opacity"
            >
              <Image src="/icons/ghicon.svg" alt="GitHub" width={28} height={28} />
            </Link>
            <Link
              href="https://x.com/EvolutionXROM"
              target="_blank"
              className="hover:opacity-80 transition-opacity"
            >
              <Image src="/icons/xlogo.svg" alt="X" width={28} height={28} />
            </Link>
            <Link
              href="https://www.gofundme.com/f/evolutionx-developers"
              target="_blank"
              className="hover:opacity-80 transition-opacity"
            >
              <Image src="/icons/donateicon.svg" alt="Donate" width={28} height={28} />
            </Link>
          </div>
        </div>

        <div className="mt-6 text-xs text-gray-400 flex flex-col md:flex-row justify-between items-center">
          <p>Designed by <Link href="https://t.me/Stock_Sucks" target="_blank" className="text-gray-300 hover:text-white">Kshitij</Link></p>
          <p className="mt-2 md:mt-0">
            Developed by <Link href="https://github.com/AnierinBliss" target="_blank" className="text-gray-300 hover:text-white">Anierin Bliss</Link>, <Link href="https://github.com/Prathamk07" target="_blank" className="text-gray-300 hover:text-white">Prathamk07</Link> & <Link href="https://github.com/ZirgomHaidar" target="_blank" className="text-gray-300 hover:text-white">Zirgom Haidar</Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
