import Image from "next/image";

type TeamMember = {
  name: string;
  role: string;
  image: string;
};

const founders: TeamMember[] = [
  {
    name: "Anierin Bliss",
    role: "Co-Founder / Co-Developer",
    image: "https://avatars.githubusercontent.com/AnierinBliss",
  },
  {
    name: "Jose Antonio Huab (Joey)",
    role: "Founder / Lead Developer",
    image: "https://avatars.githubusercontent.com/joeyhuab",
  },
  {
    name: "Akito Mizukito",
    role: "Co-Founder / Project Manager",
    image: "https://avatars.githubusercontent.com/RealAkito",
  },
];

const projectMembers: TeamMember[] = [
  {
    name: "Aidan Warner",
    role: "Maintainer Relations & Jenkins Admin",
    image: "https://ui-avatars.com/api/?name=AW&background=3c53c2&color=fff&size=180",
  },
  {
    name: "Hyde",
    role: "Community Relations",
    image: "https://avatars.githubusercontent.com/hydeplaysofficial",
  },
  {
    name: "Onelots",
    role: "Maintainer & Community Relations",
    image: "https://avatars.githubusercontent.com/Onelots",
  },
];

const maintainers: TeamMember[] = [
  {
    name: "ARIJIT SAHA",
    role: "Xiaomi Redmi Note 12 5G/Poco X5 5G",
    image: "https://ui-avatars.com/api/?name=AS&background=8a3d9e&color=fff&size=180",
  },
  {
    name: "Achille (0xSharkBoy)",
    role: "Samsung Galaxy Devices",
    image: "https://ui-avatars.com/api/?name=A&background=3c53c2&color=fff&size=180",
  },
  {
    name: "AgBKartikey",
    role: "Nothing Phone 2",
    image: "https://ui-avatars.com/api/?name=AK&background=3c53c2&color=fff&size=180",
  },
  {
    name: "Anierin Bliss",
    role: "Google Pixel Devices",
    image: "https://avatars.githubusercontent.com/AnierinBliss",
  },
];

export default function TeamPage() {
  return (
    <div className="py-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl md:text-5xl font-bold mb-16 text-center">
          Team <span className="gradient-text">Evolution X</span>
        </h1>

        {/* Founders Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-semibold mb-6 text-center">Founders</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {founders.map((member) => (
              <TeamMemberCard key={member.name} member={member} />
            ))}
          </div>
        </div>

        {/* Project Members Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-semibold mb-6 text-center">Project Members</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {projectMembers.map((member) => (
              <TeamMemberCard key={member.name} member={member} />
            ))}
          </div>
          <p className="text-center text-gray-400 mt-6">
            These are some of the people who have helped bring us here today
          </p>
        </div>

        {/* Maintainers Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-semibold mb-6 text-center">Maintainers</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {maintainers.map((member) => (
              <TeamMemberCard key={member.name} member={member} />
            ))}
          </div>
          <p className="text-center text-gray-400 mt-6">
            These are the amazing individuals maintaining Evolution X
          </p>
        </div>

        {/* About Section */}
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-semibold mb-4 gradient-text">About Evolution X</h2>
          <p className="text-gray-300">
            Evolution X is a custom Android ROM project that mimics the user experience of Google Pixel devices while enhancing it with extensive customization options. Launched in March 2019 by a team of three developers, led by Jose Antonio Huab "Joey", Evolution X has since evolved into one of the most sought-after custom ROMs.
          </p>
        </div>
      </div>
    </div>
  );
}

function TeamMemberCard({ member }: { member: TeamMember }) {
  return (
    <div className="bg-gradient-to-br from-black to-evolution-dark/70 p-4 rounded-2xl overflow-hidden">
      <div className="aspect-square w-full h-auto mb-3 relative rounded-xl overflow-hidden">
        <Image
          src={member.image}
          alt={member.name}
          width={180}
          height={180}
          className="w-full h-full object-cover"
        />
      </div>
      <h3 className="font-medium text-lg">{member.name}</h3>
      <p className="text-gray-400 text-sm">{member.role}</p>
    </div>
  );
}
