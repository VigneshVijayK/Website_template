export default function MerchPage() {
  return (
    <div className="py-12">
      <div className="container mx-auto px-6 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">
          Merch
        </h1>
        <div className="max-w-2xl mx-auto">
          <p className="text-gray-400 text-lg">
            Evolution X merchandise coming soon...
          </p>
        </div>
      </div>
    </div>
  );
}
