export default function BlogPage() {
  return (
    <div className="py-12">
      <div className="container mx-auto px-6 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">
          Blog
        </h1>
        <div className="max-w-2xl mx-auto">
          <p className="text-gray-400 text-lg">
            Blog posts coming soon...
          </p>
        </div>
      </div>
    </div>
  );
}
