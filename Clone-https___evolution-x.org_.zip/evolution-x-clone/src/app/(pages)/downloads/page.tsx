import Image from "next/image";
import Link from "next/link";

type Device = {
  name: string;
  codename: string;
  maintainer: string;
  image: string;
};

const devices: Device[] = [
  {
    name: "Xiaomi Poco F5 / Redmi Note 12 Turbo",
    codename: "marble",
    maintainer: "Joey Huab",
    image: "https://ui-avatars.com/api/?name=Poco+F5&background=3c53c2&color=fff&size=180",
  },
  {
    name: "Xiaomi Poco X5 Pro / Redmi Note 12 Pro Speed",
    codename: "redwood",
    maintainer: "Priyanshu Jangid",
    image: "https://ui-avatars.com/api/?name=Poco+X5P&background=8a3d9e&color=fff&size=180",
  },
  {
    name: "Xiaomi Mi 10 Pro",
    codename: "cmi",
    maintainer: "Giovanni (TechPanelGM)",
    image: "https://ui-avatars.com/api/?name=Mi+10P&background=3c53c2&color=fff&size=180",
  },
  {
    name: "Xiaomi Mi 10",
    codename: "umi",
    maintainer: "Giovanni (TechPanelGM)",
    image: "https://ui-avatars.com/api/?name=Mi+10&background=8a3d9e&color=fff&size=180",
  },
  {
    name: "Google Pixel 9 Pro XL",
    codename: "komodo",
    maintainer: "Oscar Mariscal",
    image: "https://ui-avatars.com/api/?name=Pixel+9PXL&background=3c53c2&color=fff&size=180",
  },
  {
    name: "Google Pixel 9 Pro",
    codename: "caiman",
    maintainer: "Oscar Mariscal",
    image: "https://ui-avatars.com/api/?name=Pixel+9P&background=8a3d9e&color=fff&size=180",
  },
  {
    name: "Google Pixel 8a",
    codename: "akita",
    maintainer: "Oscar Mariscal",
    image: "https://ui-avatars.com/api/?name=Pixel+8a&background=3c53c2&color=fff&size=180",
  },
  {
    name: "Google Pixel 8",
    codename: "shiba",
    maintainer: "Oscar Mariscal",
    image: "https://ui-avatars.com/api/?name=Pixel+8&background=8a3d9e&color=fff&size=180",
  },
];

export default function DownloadsPage() {
  return (
    <div className="py-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl md:text-5xl font-bold mb-16 text-center">
          Download
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {devices.map((device) => (
            <DeviceCard key={device.codename} device={device} />
          ))}
        </div>
      </div>
    </div>
  );
}

function DeviceCard({ device }: { device: Device }) {
  return (
    <div className="bg-gradient-to-br from-black to-evolution-dark/70 rounded-2xl overflow-hidden">
      <div className="aspect-video w-full h-auto relative">
        <Image
          src={device.image}
          alt={device.name}
          width={320}
          height={180}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="p-4">
        <h3 className="font-medium text-sm mb-1">{device.name}</h3>
        <p className="text-gray-400 text-xs mb-4">
          Maintainer: {device.maintainer}
        </p>

        <Link
          href={`/downloads/${device.codename}`}
          className="block w-full py-2 bg-blue-600 hover:bg-blue-700 text-center text-white rounded-lg text-sm transition-colors duration-300"
        >
          Get Evolution X
        </Link>
      </div>
    </div>
  );
}
