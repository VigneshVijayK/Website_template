import { Hero } from "@/components/ui/hero";
import { FeatureCards } from "@/components/ui/feature-cards";
import { PhoneShowcase } from "@/components/ui/phone-showcase";

export default function Home() {
  return (
    <div>
      <Hero />
      <FeatureCards />
      <PhoneShowcase />
    </div>
  );
}
